# Repository-removal request: superseded

Current decision: keep and deploy to `clavum-figendi/astra-chess`; the user will rename the repository themselves. The user additionally requires the new PyTorch model to run in the browser before deployment. Do not retry deletion. The notes below preserve the earlier failed removal attempt, not current instructions.

Requested disposition: permanently delete `clavum-figendi/astra-chess` on GitHub, retaining local files. This was explicitly confirmed by the user; it is not a rename/migration request.

Local project remains at `/home/hermes/projects/astra-chess`.
A complete Git bundle was created and successfully verified at `/home/hermes/projects/chess-lab-preserved.bundle` before the deletion attempt. It contains the then-current complete history and all 14 reported references. Subsequent research work remains in the local working directory.

Observed remote failures:

1. `gh repo delete clavum-figendi/astra-chess --yes` returned HTTP 403 and explicitly required the `delete_repo` OAuth scope.
2. A browser fallback could not start: the browser service returned HTTP 402. No payment/top-up was attempted.
3. An attempt to remove the Pages publication separately returned HTTP 422: `Deactivating GitHub pages for this repository is not allowed.` A readback still returned the configured Pages URL.

**The repository has not been deleted, and Pages has not been deactivated.** No new repository was created and no research/fine-tuning changes have been pushed since this removal request.

No deletion permission or manual deletion is now requested. The earlier removal request has been withdrawn in favor of deployment and a user-managed rename.
